from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()

from app.models import Usuario

@login_manager.user_loader
def cargar_usuario(id):
    return Usuario.query.get(int(id))


def create_app():

    app = Flask(__name__)

    app.config.from_object('config.Config')

    db.init_app(app)
    login_manager.init_app(app)

    from app.routes import main
    from app.auth.routes import auth

    app.register_blueprint(main)
    app.register_blueprint(auth)

    #SIN LOGIN 401
    @login_manager.unauthorized_handler
    def no_autorizado():
        return render_template('401.html'), 401

    #SIN PERMISOS 403
    @app.errorhandler(403)
    def error_403(error):
        return render_template('403.html'), 403

    return app