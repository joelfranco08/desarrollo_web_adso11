from app import db
from flask_login import UserMixin


class Usuario(UserMixin, db.Model):

    id = db.Column(db.Integer, primary_key=True)

    nombre = db.Column(db.String(100), nullable=False)

    correo = db.Column(db.String(100), unique=True, nullable=False)

    contraseña = db.Column(db.String(255), nullable=False)

    rol = db.Column(db.String(20), nullable=False)

    bio = db.Column(db.Text)

    # eventos donde participa como asistente
    inscripciones = db.relationship('Inscripcion', backref='usuario', lazy=True)

    # eventos que crea como organizador (opcional pero recomendado)
    eventos_creados = db.relationship('Evento', backref='organizador', lazy=True)


class Evento(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    titulo = db.Column(db.String(100), nullable=False)

    descripcion = db.Column(db.Text, nullable=False)

    categoria = db.Column(db.String(50), nullable=False)

    cupo = db.Column(db.Integer, nullable=False)

    organizador_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

    inscripciones = db.relationship('Inscripcion', backref='evento', lazy=True)


class Inscripcion(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

    evento_id = db.Column(db.Integer, db.ForeignKey('evento.id'), nullable=False)

    fecha = db.Column(db.DateTime, default=db.func.current_timestamp())