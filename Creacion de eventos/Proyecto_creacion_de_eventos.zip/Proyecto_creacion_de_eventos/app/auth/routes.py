from flask import Blueprint, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask import redirect, url_for, flash, session, make_response
from flask_login import logout_user, login_required
from flask_login import login_user, logout_user, login_required, current_user

from app.models import Usuario
from app import db

auth = Blueprint('auth', __name__)



# REGISTRO

@auth.route('/registro', methods=['GET', 'POST'])
def registro():

    if request.method == 'POST':

        nombre = request.form['nombre']
        correo = request.form['correo']
        contraseña = request.form['contraseña']
        rol = request.form['rol']

        usuario_existente = Usuario.query.filter_by(correo=correo).first()

        if usuario_existente:
            flash("El correo ya está registrado")
            return redirect(url_for('auth.registro'))

        nuevo = Usuario(
            nombre=nombre,
            correo=correo,
            contraseña=generate_password_hash(contraseña),
            rol=rol
        )

        db.session.add(nuevo)
        db.session.commit()

        flash("Usuario registrado correctamente")

        return redirect(url_for('auth.login'))

    return render_template('registro.html')



# LOGIN

@auth.route('/login', methods=['GET', 'POST'])
def login():

    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    if request.method == 'POST':

        correo = request.form['correo']
        contraseña = request.form['contraseña']

        usuario = Usuario.query.filter_by(correo=correo).first()

        if not usuario:
            flash("Correo no registrado")
            return redirect(url_for('auth.login'))

        if not check_password_hash(usuario.contraseña, contraseña):
            flash("Contraseña incorrecta")
            return redirect(url_for('auth.login'))

        login_user(usuario)
        flash("Inicio de sesión exitoso")

        return redirect(url_for('main.index'))

    return render_template('login.html')


# -------------------------
# LOGOUT
# -------------------------
@auth.route('/logout')
@login_required
def logout():


    logout_user()

    session.pop('_user_id', None)

    session.clear()

    response = make_response(
        redirect(url_for('auth.login'))
    )

    response.delete_cookie('session')

    return response