from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.models import Evento, Inscripcion
from app import db
from app.decoradores import rol_requerido

main = Blueprint('main', __name__)



# ROOT
@main.route('/')
def root():

    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    return redirect(url_for('auth.login'))


# INDEX CON FILTRO DINÁMICO
@main.route('/index')
@login_required
def index():

    categoria = request.args.get('categoria')

    # eventos
    if categoria:
        eventos = Evento.query.filter_by(categoria=categoria).all()
    else:
        eventos = Evento.query.all()

    # categorías dinámicas
    categorias_db = db.session.query(Evento.categoria).distinct().all()
    categorias = [c[0] for c in categorias_db if c[0]]

    # si no hay categorías aún
    if not categorias:
        categorias = ["tecnologia", "educacion", "negocios"]

    return render_template(
        'index.html',
        eventos=eventos,
        categorias=categorias
    )


# CREAR EVENTO
@main.route('/crear', methods=['GET', 'POST'])
@login_required
@rol_requerido('organizador')
def crear_evento():

    if request.method == 'POST':

        nuevo = Evento(
            titulo=request.form['titulo'],
            descripcion=request.form['descripcion'],
            categoria=request.form['categoria'].lower().strip(),
            cupo=int(request.form['cupo']),
            organizador_id=current_user.id
        )

        db.session.add(nuevo)
        db.session.commit()

        flash("Evento creado correctamente")

        return redirect(url_for('main.index'))

    return render_template('crear_evento.html')


# EDITAR EVENTO
@main.route('/editar/<int:id>', methods=['GET', 'POST'])
@login_required
@rol_requerido('organizador')
def editar_evento(id):

    evento = Evento.query.get_or_404(id)

    if request.method == 'POST':

        evento.titulo = request.form['titulo']
        evento.descripcion = request.form['descripcion']
        evento.categoria = request.form['categoria'].lower().strip()
        evento.cupo = int(request.form['cupo'])

        db.session.commit()

        flash("Evento actualizado")

        return redirect(url_for('main.index'))

    return render_template('editar_evento.html', evento=evento)


# ELIMINAR EVENTO
@main.route('/eliminar/<int:id>')
@login_required
@rol_requerido('organizador')
def eliminar_evento(id):

    evento = Evento.query.get_or_404(id)
    ####parte de ai solucion de eror sqlalchemy
 # verificar si hay inscritos
    inscritos = Inscripcion.query.filter_by(
        evento_id=evento.id
    ).count()

    if inscritos > 0:

        flash("No se puede eliminar el evento porque hay usuarios inscritos")

        return redirect(url_for('main.index'))
    #######
    db.session.delete(evento)
    db.session.commit()

    flash("Evento eliminado")

    return redirect(url_for('main.index'))


# INSCRIBIRSE
@main.route('/inscribirse/<int:evento_id>')
@login_required
@rol_requerido('asistente')
def inscribirse(evento_id):

    evento = Evento.query.get_or_404(evento_id)

    existe = Inscripcion.query.filter_by(
        usuario_id=current_user.id,
        evento_id=evento.id
    ).first()

    if existe:
        flash("Ya estás inscrito")
        return redirect(url_for('main.index'))

    total = Inscripcion.query.filter_by(evento_id=evento.id).count()

    if total >= evento.cupo:
        flash("No hay cupo")
        return redirect(url_for('main.index'))

    nueva = Inscripcion(
        usuario_id=current_user.id,
        evento_id=evento.id
    )

    db.session.add(nueva)
    db.session.commit()

    flash("Inscripción exitosa")

    return redirect(url_for('main.index'))


 
# CANCELAR INSCRIPCIÓN
 
@main.route('/cancelar/<int:evento_id>')
@login_required
@rol_requerido('asistente')
def cancelar(evento_id):

    inscripcion = Inscripcion.query.filter_by(
        usuario_id=current_user.id,
        evento_id=evento_id
    ).first()

    if not inscripcion:
        flash("No estás inscrito")
        return redirect(url_for('main.index'))

    db.session.delete(inscripcion)
    db.session.commit()

    flash("Inscripción cancelada")

    return redirect(url_for('main.index'))


 
# PERFIL
 
@main.route('/perfil')
@login_required
def perfil():

    inscripciones = current_user.inscripciones
    eventos_creados = current_user.eventos_creados

    return render_template(
        'perfil.html',
        usuario=current_user,
        inscripciones=inscripciones,
        eventos_creados=eventos_creados
    )


 
# EDITAR BIO
 
@main.route('/editar_bio', methods=['POST'])
@login_required
def editar_bio():

    current_user.bio = request.form['bio']

    db.session.commit()

    flash("Bio actualizada")

    return redirect(url_for('main.perfil'))