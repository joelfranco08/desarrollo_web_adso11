from functools import wraps

from flask_login import current_user

from flask import abort


def rol_requerido(rol):

    def decorador(funcion):

        @wraps(funcion)
        def envoltura(*args, **kwargs):

            if current_user.rol != rol:

                abort(403)

            return funcion(*args, **kwargs)

        return envoltura

    return decorador